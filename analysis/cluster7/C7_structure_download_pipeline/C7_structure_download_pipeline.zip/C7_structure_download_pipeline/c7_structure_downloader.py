#!/usr/bin/env python3
"""
Download and assemble Cluster 7 FoldTree candidate structures.

Stages
------
stage1
    Select and download:
      1. top nonredundant MGnify-ESM30 candidates;
      2. high-confidence LPS/O-antigen glycosyltransferase anchors.

stage2
    Download the edge-informed Cluster 7 neighborhood/backbone.

merge
    Merge successful stage1 and stage2 downloads into one deduplicated
    structure directory and write a FoldMason/FoldTree input manifest.

all
    Run stage1, stage2, and merge.

Public coordinate sources
-------------------------
MGYP accessions:
    ESM Metagenomic Atlas:
    https://api.esmatlas.com/fetchPredictedStructure/{MGYP}.pdb

UniProt / AlphaFold accessions:
    AlphaFold DB API:
    https://alphafold.ebi.ac.uk/api/prediction/{ACCESSION}

PDB accessions:
    RCSB:
    https://files.rcsb.org/download/{PDB}.cif

The downloader is serial by default, resumes existing valid files, and uses
manual exponential backoff for HTTP 403, 429, and transient 5xx responses.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import numpy as np
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


MGYP_RE = re.compile(r"(MGYP\d{12})", re.I)
AF_MODEL_RE = re.compile(
    r"(AF-([A-Z0-9]+(?:-\d+)?)-F\d+-model_v\d+)",
    re.I,
)
UNIPROT_RE = re.compile(
    r"^(?:"
    r"[A-NR-Z][0-9][A-Z0-9]{3}[0-9]"
    r"|[OPQ][0-9][A-Z0-9]{3}[0-9]"
    r"|A0A[A-Z0-9]{7}"
    r")(?:-\d+)?$",
    re.I,
)
PDB_RE = re.compile(r"^([0-9][A-Z0-9]{3})(?:[_:\-.]([A-Za-z0-9]+))?$", re.I)

TRANSIENT_STATUSES = {403, 408, 425, 429, 500, 502, 503, 504}
STRUCTURE_SUFFIXES = (
    ".pdb", ".cif", ".mmcif",
    ".pdb.gz", ".cif.gz", ".mmcif.gz",
)


def build_session() -> requests.Session:
    retry = Retry(
        total=5,
        connect=5,
        read=5,
        status=0,  # status retries are handled manually below
        backoff_factor=1.0,
        allowed_methods=frozenset({"GET"}),
    )
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Cluster7-structure-downloader/1.0",
        "Accept": "application/json, chemical/x-pdb, text/plain, */*",
    })
    session.mount("https://", HTTPAdapter(max_retries=retry))
    return session


def request_with_backoff(
    session: requests.Session,
    url: str,
    *,
    timeout: int = 180,
    attempts: int = 7,
    initial_backoff: float = 2.0,
) -> requests.Response:
    last_response: requests.Response | None = None
    for attempt in range(1, attempts + 1):
        response = session.get(url, timeout=timeout)
        last_response = response
        if response.status_code == 200:
            return response
        if response.status_code not in TRANSIENT_STATUSES:
            response.raise_for_status()

        if attempt < attempts:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    sleep_seconds = float(retry_after)
                except ValueError:
                    sleep_seconds = initial_backoff * (2 ** (attempt - 1))
            else:
                sleep_seconds = initial_backoff * (2 ** (attempt - 1))
            sleep_seconds = min(sleep_seconds, 120.0)
            print(
                f"  HTTP {response.status_code} for {url}; "
                f"retrying in {sleep_seconds:.1f}s",
                file=sys.stderr,
                flush=True,
            )
            time.sleep(sleep_seconds)

    assert last_response is not None
    last_response.raise_for_status()
    return last_response


def recursive_urls(obj: Any) -> list[str]:
    urls: list[str] = []
    if isinstance(obj, dict):
        for value in obj.values():
            urls.extend(recursive_urls(value))
    elif isinstance(obj, list):
        for value in obj:
            urls.extend(recursive_urls(value))
    elif isinstance(obj, str) and obj.startswith(("https://", "http://")):
        urls.append(obj)
    return urls


def normalize_target(raw: str) -> tuple[str, str, str]:
    """
    Return canonical accession, source type, and original target string.
    """
    original = str(raw).strip()

    mgyp = MGYP_RE.search(original)
    if mgyp:
        accession = mgyp.group(1).upper()
        return accession, "MGnify_ESM_Atlas", original

    af = AF_MODEL_RE.search(original)
    if af:
        model_id = af.group(1)
        uniprot = af.group(2).upper()
        return uniprot, "AlphaFold_DB", original

    token = original.split()[0]
    token = re.sub(r"\.(pdb|cif|mmcif)(\.gz)?$", "", token, flags=re.I)

    if UNIPROT_RE.fullmatch(token):
        return token.upper(), "AlphaFold_DB", original

    pdb_match = PDB_RE.fullmatch(token)
    if pdb_match:
        return pdb_match.group(1).upper(), "RCSB_PDB", original

    return token, "unresolved", original


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_structure_content(content: bytes) -> bool:
    if not content:
        return False
    head = content[:5000].decode("utf-8", errors="ignore").lstrip()
    if head.startswith(("<", "{", "[")):
        return False
    markers = ("\nATOM ", "\nHETATM", "\nMODEL ", "data_")
    padded = "\n" + head
    return any(marker in padded for marker in markers)


def validate_structure_file(path: Path) -> bool:
    if not path.exists() or path.stat().st_size < 100:
        return False
    try:
        content = path.read_bytes()[:5000]
    except OSError:
        return False
    return is_structure_content(content)


def write_content_atomic(content: bytes, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".part")
    temporary.write_bytes(content)
    if not validate_structure_file(temporary):
        temporary.unlink(missing_ok=True)
        raise ValueError("Downloaded content is not a recognizable PDB/mmCIF file")
    temporary.replace(destination)


def download_mgnify(
    session: requests.Session,
    accession: str,
    destination: Path,
) -> tuple[str, str]:
    urls = [
        f"https://api.esmatlas.com/fetchPredictedStructure/{accession}.pdb",
        f"https://api.esmatlas.com/fetchPredictedStructure/{accession}",
    ]
    errors = []
    for url in urls:
        try:
            response = request_with_backoff(session, url)
            write_content_atomic(response.content, destination)
            return url, "downloaded_ESM_Atlas"
        except Exception as exc:
            errors.append(f"{url}:{type(exc).__name__}:{exc}")
    raise RuntimeError("; ".join(errors))


def download_alphafold(
    session: requests.Session,
    accession: str,
    original_target: str,
    destination: Path,
) -> tuple[str, str]:
    api_url = f"https://alphafold.ebi.ac.uk/api/prediction/{accession}"
    errors = []

    try:
        response = request_with_backoff(session, api_url, timeout=120)
        payload = response.json()
        urls = recursive_urls(payload)

        pdb_urls = [
            url for url in urls
            if re.search(r"\.pdb(?:\?|$)", url, re.I)
        ]
        cif_urls = [
            url for url in urls
            if re.search(r"\.(?:cif|mmcif)(?:\?|$)", url, re.I)
        ]

        for url in pdb_urls + cif_urls:
            try:
                coordinate_response = request_with_backoff(
                    session, url, timeout=240
                )
                write_content_atomic(
                    coordinate_response.content,
                    destination,
                )
                return url, "downloaded_AlphaFold_API"
            except Exception as exc:
                errors.append(f"{url}:{type(exc).__name__}:{exc}")
    except Exception as exc:
        errors.append(f"{api_url}:{type(exc).__name__}:{exc}")

    # Direct-model fallback. Prefer the exact model identifier from the
    # Foldseek target; then try current/recent AlphaFold DB versions.
    direct_model_ids = []
    model_match = AF_MODEL_RE.search(original_target)
    if model_match:
        direct_model_ids.append(model_match.group(1))
    direct_model_ids.extend(
        f"AF-{accession}-F1-model_v{version}"
        for version in range(6, 2, -1)
    )

    seen = set()
    for model_id in direct_model_ids:
        if model_id in seen:
            continue
        seen.add(model_id)
        url = f"https://alphafold.ebi.ac.uk/files/{model_id}.pdb"
        try:
            response = request_with_backoff(session, url, timeout=240)
            write_content_atomic(response.content, destination)
            return url, "downloaded_AlphaFold_direct"
        except Exception as exc:
            errors.append(f"{url}:{type(exc).__name__}:{exc}")

    raise RuntimeError("; ".join(errors))


def download_rcsb(
    session: requests.Session,
    accession: str,
    destination: Path,
) -> tuple[str, str]:
    url = f"https://files.rcsb.org/download/{accession}.cif"
    response = request_with_backoff(session, url, timeout=240)
    write_content_atomic(response.content, destination)
    return url, "downloaded_RCSB"


def structure_suffix(source_type: str) -> str:
    return ".cif" if source_type == "RCSB_PDB" else ".pdb"


def index_local_structures(directory: Path | None) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = defaultdict(list)
    if directory is None:
        return index
    if not directory.exists():
        raise FileNotFoundError(f"Local structure directory not found: {directory}")

    for path in directory.rglob("*"):
        if not path.is_file():
            continue
        if not path.name.lower().endswith(STRUCTURE_SUFFIXES):
            continue

        stem = path.name
        for suffix in sorted(STRUCTURE_SUFFIXES, key=len, reverse=True):
            if stem.lower().endswith(suffix):
                stem = stem[:-len(suffix)]
                break

        candidates = {stem.upper()}
        for pattern in (MGYP_RE, AF_MODEL_RE):
            match = pattern.search(stem)
            if match:
                if pattern is MGYP_RE:
                    candidates.add(match.group(1).upper())
                else:
                    candidates.add(match.group(2).upper())

        for candidate in candidates:
            index[candidate].append(path)
    return index


def choose_local(
    accession: str,
    local_index: dict[str, list[Path]],
) -> Path | None:
    candidates = [
        path for path in local_index.get(accession.upper(), [])
        if validate_structure_file(path)
    ]
    if not candidates:
        return None
    candidates.sort(key=lambda path: (len(path.name), path.name))
    return candidates[0]


def parse_pdb_qc(path: Path) -> dict[str, Any]:
    """
    Count CA residues and estimate mean confidence from the PDB B-factor field.

    ESM Atlas PDBs may encode confidence on a 0–1 scale, whereas AlphaFold DB
    commonly uses 0–100. The scale is detected automatically.
    """
    if path.suffix.lower() != ".pdb":
        return {
            "ca_residue_count": "",
            "mean_confidence": "",
            "fraction_confidence_ge70": "",
            "confidence_scale_detected": "",
        }

    b_factors = []
    residue_keys = set()
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.startswith(("ATOM  ", "HETATM")):
                continue
            atom_name = line[12:16].strip()
            if atom_name != "CA":
                continue
            chain = line[21:22]
            residue_number = line[22:26]
            insertion_code = line[26:27]
            residue_keys.add((chain, residue_number, insertion_code))
            try:
                b_factors.append(float(line[60:66]))
            except ValueError:
                pass

    if not b_factors:
        return {
            "ca_residue_count": len(residue_keys),
            "mean_confidence": "",
            "fraction_confidence_ge70": "",
            "confidence_scale_detected": "",
        }

    maximum = max(b_factors)
    if maximum <= 1.5:
        values = [value * 100.0 for value in b_factors]
        scale = "0_to_1_scaled_to_100"
    else:
        values = b_factors
        scale = "0_to_100"

    return {
        "ca_residue_count": len(residue_keys),
        "mean_confidence": sum(values) / len(values),
        "fraction_confidence_ge70": (
            sum(value >= 70.0 for value in values) / len(values)
        ),
        "confidence_scale_detected": scale,
    }


def read_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", dtype=str).replace({np.nan: ""})


def numeric_column(df: pd.DataFrame, name: str) -> pd.Series:
    if name not in df.columns:
        raise ValueError(f"Required column absent: {name}")
    return pd.to_numeric(df[name], errors="coerce")


def select_mgnify(
    path: Path,
    top_n: int,
    min_normalized_score: float,
) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t")

    required = {
        "candidate_class",
        "target",
        "seed_support",
        "min_probability_across_seeds",
        "worst_evalue_across_seeds",
        "min_query_coverage_across_seeds",
        "min_target_coverage_across_seeds",
        "min_self_normalized_score",
        "target_length",
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"MGnify candidate file lacks columns: {sorted(missing)}")

    selected = df[
        (df["candidate_class"] == "MGnify_strong_C7_like")
        & (df["seed_support"] >= 3)
        & (df["min_probability_across_seeds"] >= 0.999)
        & (df["min_query_coverage_across_seeds"] >= 0.90)
        & (df["min_target_coverage_across_seeds"] >= 0.80)
        & (df["min_self_normalized_score"] >= min_normalized_score)
    ].copy()

    selected = selected.sort_values(
        [
            "min_self_normalized_score",
            "min_target_coverage_across_seeds",
            "worst_evalue_across_seeds",
        ],
        ascending=[False, False, True],
    ).head(top_n)

    rows = []
    for rank, (_, row) in enumerate(selected.iterrows(), start=1):
        accession, source_type, original = normalize_target(row["target"])
        rows.append({
            "selection_rank": rank,
            "canonical_id": accession,
            "original_target": original,
            "group": "MGnify_top_C7_like",
            "source_type": source_type,
            "target_header": row.get("target_header", ""),
            "seed_support": row["seed_support"],
            "probability": row["min_probability_across_seeds"],
            "evalue": row["worst_evalue_across_seeds"],
            "query_coverage": row["min_query_coverage_across_seeds"],
            "target_coverage": row["min_target_coverage_across_seeds"],
            "foldseek_score": row["min_raw_score_across_seeds"],
            "self_normalized_score": row["min_self_normalized_score"],
            "expected_length": row["target_length"],
            "selection_reason": (
                "Top MGnify candidate recovered by all three C7 medoids; "
                "high full-core coverage and strong worst-medoid normalized score"
            ),
            "foldtree_qc_note": "Full-length candidate; still inspect FoldMason core",
        })
    return pd.DataFrame(rows)


def select_lps(
    path: Path,
    min_support: int,
    min_probability: float,
    min_query_coverage: float,
    min_target_coverage: float,
) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t")

    required = {
        "target",
        "target_header",
        "medoid_support",
        "worst_probability",
        "worst_evalue",
        "maximum_score",
        "minimum_query_coverage",
        "minimum_target_coverage",
        "target_length",
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"LPS hit file lacks columns: {sorted(missing)}")

    selected = df[
        (df["medoid_support"] >= min_support)
        & (df["worst_probability"] >= min_probability)
        & (df["minimum_query_coverage"] >= min_query_coverage)
        & (df["minimum_target_coverage"] >= min_target_coverage)
    ].copy()

    selected = selected.sort_values(
        [
            "medoid_support",
            "maximum_score",
            "minimum_target_coverage",
            "worst_evalue",
        ],
        ascending=[False, False, False, True],
    )

    rows = []
    for rank, (_, row) in enumerate(selected.iterrows(), start=1):
        accession, source_type, original = normalize_target(row["target"])
        rows.append({
            "selection_rank": rank,
            "canonical_id": accession,
            "original_target": original,
            "group": "LPS_O_antigen_anchor",
            "source_type": source_type,
            "target_header": row["target_header"],
            "seed_support": row["medoid_support"],
            "probability": row["worst_probability"],
            "evalue": row["worst_evalue"],
            "query_coverage": row["minimum_query_coverage"],
            "target_coverage": row["minimum_target_coverage"],
            "foldseek_score": row["maximum_score"],
            "self_normalized_score": "",
            "expected_length": row["target_length"],
            "selection_reason": (
                "Repeated annotated LPS/O-antigen GT hit with high query coverage "
                "and substantial target coverage"
            ),
            "foldtree_qc_note": (
                "Functional anchor; inspect extra domains/extensions and trim to "
                "the shared GT-like core before final FoldTree"
            ),
        })
    return pd.DataFrame(rows)


def select_neighbors(
    ids_path: Path,
    manifest_path: Path | None,
) -> pd.DataFrame:
    metadata: dict[str, dict[str, Any]] = {}
    if manifest_path is not None:
        manifest = pd.read_csv(manifest_path, sep="\t")
        if "name" in manifest.columns:
            metadata = {
                str(row["name"]): row.to_dict()
                for _, row in manifest.iterrows()
            }

    ids = []
    for line in ids_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        ids.append(line.split()[0])

    rows = []
    for rank, identifier in enumerate(dict.fromkeys(ids), start=1):
        accession, source_type, original = normalize_target(identifier)
        meta = metadata.get(identifier, {})
        rows.append({
            "selection_rank": rank,
            "canonical_id": accession,
            "original_target": original,
            "group": "C7_edge_informed_neighborhood",
            "source_type": source_type,
            "target_header": meta.get("species", ""),
            "seed_support": "",
            "probability": "",
            "evalue": "",
            "query_coverage": "",
            "target_coverage": "",
            "foldseek_score": "",
            "self_normalized_score": "",
            "expected_length": "",
            "selection_reason": meta.get(
                "panel_role",
                "Edge-informed Cluster 7 network member",
            ),
            "foldtree_qc_note": (
                "Network backbone; verify complete common core and fragment status"
            ),
        })
    return pd.DataFrame(rows)


MANIFEST_COLUMNS = [
    "selection_rank",
    "canonical_id",
    "original_target",
    "group",
    "source_type",
    "target_header",
    "seed_support",
    "probability",
    "evalue",
    "query_coverage",
    "target_coverage",
    "foldseek_score",
    "self_normalized_score",
    "expected_length",
    "selection_reason",
    "foldtree_qc_note",
]


def write_dataframe(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, sep="\t", index=False)


def download_manifest(
    manifest: pd.DataFrame,
    outdir: Path,
    local_structure_dir: Path | None,
    sleep_seconds: float,
) -> pd.DataFrame:
    outdir.mkdir(parents=True, exist_ok=True)
    session = build_session()
    local_index = index_local_structures(local_structure_dir)

    records = []
    for index, row in manifest.iterrows():
        accession = str(row["canonical_id"])
        source_type = str(row["source_type"])
        original_target = str(row["original_target"])
        group = str(row["group"])
        suffix = structure_suffix(source_type)
        destination = outdir / f"{accession}{suffix}"

        status = ""
        source_url = ""
        error = ""

        if validate_structure_file(destination):
            status = "resumed_existing"
        else:
            local = choose_local(accession, local_index)
            if local is not None:
                shutil.copy2(local, destination)
                status = "copied_local"
                source_url = str(local.resolve())
            else:
                try:
                    if source_type == "MGnify_ESM_Atlas":
                        source_url, status = download_mgnify(
                            session, accession, destination
                        )
                    elif source_type == "AlphaFold_DB":
                        source_url, status = download_alphafold(
                            session,
                            accession,
                            original_target,
                            destination,
                        )
                    elif source_type == "RCSB_PDB":
                        source_url, status = download_rcsb(
                            session, accession, destination
                        )
                    else:
                        raise ValueError(
                            f"No automatic resolver for {source_type}: "
                            f"{original_target}"
                        )
                except Exception as exc:
                    status = "failed"
                    error = f"{type(exc).__name__}: {exc}"
                    destination.unlink(missing_ok=True)

                if sleep_seconds > 0:
                    time.sleep(sleep_seconds)

        qc = parse_pdb_qc(destination) if validate_structure_file(destination) else {
            "ca_residue_count": "",
            "mean_confidence": "",
            "fraction_confidence_ge70": "",
            "confidence_scale_detected": "",
        }

        expected_length = row.get("expected_length", "")
        try:
            expected_length_number = float(expected_length)
            ca_count = float(qc["ca_residue_count"])
            length_ratio = ca_count / expected_length_number
        except (TypeError, ValueError, ZeroDivisionError):
            length_ratio = ""

        record = row.to_dict()
        record.update({
            "download_status": status,
            "structure_path": (
                str(destination.resolve())
                if validate_structure_file(destination)
                else ""
            ),
            "source_url": source_url,
            "error": error,
            "file_size_bytes": (
                destination.stat().st_size
                if validate_structure_file(destination)
                else ""
            ),
            "sha256": (
                sha256_file(destination)
                if validate_structure_file(destination)
                else ""
            ),
            **qc,
            "observed_to_expected_length_ratio": length_ratio,
        })
        records.append(record)

        print(
            f"[{index + 1}/{len(manifest)}] {group} {accession}: {status}",
            flush=True,
        )

    output = pd.DataFrame(records)
    write_dataframe(output, outdir.parent / f"{outdir.name}_download_manifest.tsv")
    failed = output[output["download_status"] == "failed"]
    write_dataframe(failed, outdir.parent / f"{outdir.name}_failed.tsv")
    return output


def merge_manifests(
    manifest_paths: list[Path],
    outdir: Path,
) -> pd.DataFrame:
    outdir.mkdir(parents=True, exist_ok=True)
    structure_dir = outdir / "structures"
    structure_dir.mkdir(exist_ok=True)

    frames = [
        pd.read_csv(path, sep="\t", dtype=str).fillna("")
        for path in manifest_paths
    ]
    combined = pd.concat(frames, ignore_index=True)

    successful = combined[
        combined["structure_path"].astype(str).str.len() > 0
    ].copy()

    records = []
    for accession, group in successful.groupby("canonical_id", sort=False):
        rows = group.to_dict("records")
        source_paths = [
            Path(row["structure_path"])
            for row in rows
            if Path(row["structure_path"]).exists()
        ]
        if not source_paths:
            continue

        source_paths.sort(
            key=lambda path: (
                0 if path.suffix.lower() == ".pdb" else 1,
                -path.stat().st_size,
            )
        )
        source = source_paths[0]
        destination = structure_dir / f"{accession}{source.suffix.lower()}"
        if not destination.exists():
            shutil.copy2(source, destination)

        category_values = sorted({
            row["group"] for row in rows if row.get("group")
        })
        notes = sorted({
            row["foldtree_qc_note"]
            for row in rows
            if row.get("foldtree_qc_note")
        })
        headers = sorted({
            row["target_header"]
            for row in rows
            if row.get("target_header")
        })

        records.append({
            "canonical_id": accession,
            "groups": ";".join(category_values),
            "target_headers": " | ".join(headers),
            "structure_path": str(destination.resolve()),
            "source_structure_paths": ";".join(
                str(path.resolve()) for path in source_paths
            ),
            "sha256": sha256_file(destination),
            "foldtree_qc_notes": " | ".join(notes),
            "requires_core_inspection": "yes",
        })

    merged = pd.DataFrame(records).sort_values(
        ["groups", "canonical_id"]
    )
    write_dataframe(merged, outdir / "foldtree_input_manifest.tsv")

    absolute_paths = "\n".join(merged["structure_path"]) + "\n"
    (outdir / "foldtree_input_paths.txt").write_text(
        absolute_paths,
        encoding="utf-8",
    )

    relative_paths = "\n".join(
        str(Path("structures") / Path(path).name)
        for path in merged["structure_path"]
    ) + "\n"
    (outdir / "foldtree_input_relative_paths.txt").write_text(
        relative_paths,
        encoding="utf-8",
    )

    (outdir / "FOLDTREE_NEXT_STEP.txt").write_text(
        """Do not interpret a full-length tree immediately.

1. Run FoldMason on all structures.
2. Inspect:
   - whether the same GT-like core is aligned,
   - fragment status,
   - long N/C-terminal additions,
   - low-confidence internal regions.
3. Trim LPS/O-antigen anchors and other multidomain proteins to the common core.
4. Run:
   A. full-length diagnostic tree,
   B. common-core FoldTree,
   C. sensitivity tree excluding broad-fold controls.
5. Map group labels from foldtree_input_manifest.tsv onto the topology.

The primary question is whether C7 and MGnify proteins form a coherent lineage
that approaches the LPS/O-antigen anchors through the C7 network intermediates.
""",
        encoding="utf-8",
    )
    return merged


def stage1(args: argparse.Namespace) -> tuple[Path, pd.DataFrame]:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    mgnify = select_mgnify(
        Path(args.mgnify_hits),
        args.mgnify_top,
        args.mgnify_min_normalized_score,
    )
    lps = select_lps(
        Path(args.lps_hits),
        args.lps_min_support,
        args.lps_min_probability,
        args.lps_min_query_coverage,
        args.lps_min_target_coverage,
    )
    selection = pd.concat([mgnify, lps], ignore_index=True)
    selection_path = outdir / "stage1_selection.tsv"
    write_dataframe(selection, selection_path)

    downloaded = download_manifest(
        selection,
        outdir / "stage1_structures",
        Path(args.local_structure_dir) if args.local_structure_dir else None,
        args.sleep_seconds,
    )
    return outdir / "stage1_structures_download_manifest.tsv", downloaded


def stage2(args: argparse.Namespace) -> tuple[Path, pd.DataFrame]:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    selection = select_neighbors(
        Path(args.neighbor_ids),
        Path(args.neighbor_manifest) if args.neighbor_manifest else None,
    )
    selection_path = outdir / "stage2_neighborhood_selection.tsv"
    write_dataframe(selection, selection_path)

    downloaded = download_manifest(
        selection,
        outdir / "stage2_neighborhood_structures",
        Path(args.local_structure_dir) if args.local_structure_dir else None,
        args.sleep_seconds,
    )
    return (
        outdir / "stage2_neighborhood_structures_download_manifest.tsv",
        downloaded,
    )


def cmd_stage1(args: argparse.Namespace) -> int:
    manifest_path, downloaded = stage1(args)
    print(f"Stage 1 manifest: {manifest_path}")
    print(
        f"Successful: {(downloaded.download_status != 'failed').sum()} / "
        f"{len(downloaded)}"
    )
    return 0


def cmd_stage2(args: argparse.Namespace) -> int:
    manifest_path, downloaded = stage2(args)
    print(f"Stage 2 manifest: {manifest_path}")
    print(
        f"Successful: {(downloaded.download_status != 'failed').sum()} / "
        f"{len(downloaded)}"
    )
    return 0


def cmd_merge(args: argparse.Namespace) -> int:
    merged = merge_manifests(
        [Path(path) for path in args.manifest],
        Path(args.outdir),
    )
    print(f"Merged FoldTree input structures: {len(merged)}")
    print(Path(args.outdir) / "foldtree_input_manifest.tsv")
    return 0


def cmd_all(args: argparse.Namespace) -> int:
    stage1_path, stage1_downloaded = stage1(args)
    stage2_path, stage2_downloaded = stage2(args)
    merged = merge_manifests(
        [stage1_path, stage2_path],
        Path(args.outdir) / "foldtree_input",
    )
    print(
        json.dumps(
            {
                "stage1_selected": len(stage1_downloaded),
                "stage2_selected": len(stage2_downloaded),
                "merged_unique_structures": len(merged),
            },
            indent=2,
        )
    )
    return 0


def add_common_download_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--local-structure-dir")
    parser.add_argument(
        "--sleep-seconds",
        type=float,
        default=2.0,
        help="Polite delay between successful/failed public downloads",
    )


def add_stage1_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--mgnify-hits", required=True)
    parser.add_argument("--lps-hits", required=True)
    parser.add_argument("--mgnify-top", type=int, default=15)
    parser.add_argument(
        "--mgnify-min-normalized-score",
        type=float,
        default=0.18,
    )
    parser.add_argument("--lps-min-support", type=int, default=2)
    parser.add_argument("--lps-min-probability", type=float, default=0.85)
    parser.add_argument("--lps-min-query-coverage", type=float, default=0.85)
    parser.add_argument("--lps-min-target-coverage", type=float, default=0.60)


def add_stage2_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--neighbor-ids", required=True)
    parser.add_argument("--neighbor-manifest")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Download C7 MGnify, LPS/O-antigen, and network structures",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_stage1 = subparsers.add_parser("stage1")
    add_stage1_args(p_stage1)
    add_common_download_args(p_stage1)
    p_stage1.set_defaults(func=cmd_stage1)

    p_stage2 = subparsers.add_parser("stage2")
    add_stage2_args(p_stage2)
    add_common_download_args(p_stage2)
    p_stage2.set_defaults(func=cmd_stage2)

    p_merge = subparsers.add_parser("merge")
    p_merge.add_argument(
        "--manifest",
        action="append",
        required=True,
        help="Download manifest; supply once per stage",
    )
    p_merge.add_argument("--outdir", required=True)
    p_merge.set_defaults(func=cmd_merge)

    p_all = subparsers.add_parser("all")
    add_stage1_args(p_all)
    add_stage2_args(p_all)
    add_common_download_args(p_all)
    p_all.set_defaults(func=cmd_all)

    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
