# Cluster 7 structure-download and FoldTree-input pipeline

This package separates the workflow into three controlled stages.

```text
Stage 1
Top MGnify C7-like hits + LPS/O-antigen functional anchors
        ↓
Stage 2
Edge-informed Cluster 7 neighborhood
        ↓
Merge
Deduplicated FoldMason/FoldTree input
```

## Why the stages remain separate

The groups have different evidentiary roles:

- **MGnify top hits** test whether Cluster 7 belongs to a larger environmental
  lineage.
- **LPS/O-antigen hits** are annotated functional anchors, not automatically
  direct Cluster 7 homologs.
- **C7 neighborhood proteins** preserve the network-grounded path through C006
  and C003.

The script does not trim domains automatically. The LPS/O-antigen proteins are
often longer than Cluster 7 and must be inspected in FoldMason before a final
common-core FoldTree.

## Install

```bash
unzip C7_structure_download_pipeline.zip
cd C7_structure_download_pipeline
python -m pip install -r requirements.txt
python -m py_compile c7_structure_downloader.py
```

## Stage 1: download MGnify top 15 and the high-confidence LPS/O-antigen set

Default LPS/O-antigen criteria:

```text
medoid support       ≥ 2
worst probability    ≥ 0.85
minimum query cov.   ≥ 0.85
minimum target cov.  ≥ 0.60
```

With the supplied tables, this selects:

```text
15 MGnify C7-like candidates
 8 LPS/O-antigen anchors
23 total Stage-1 structures
```

Run:

```bash
python c7_structure_downloader.py stage1 \
  --mgnify-hits C7_novel_priority_candidates.tsv \
  --lps-hits C7_LPS_Oantigen_Foldseek_hits.tsv \
  --mgnify-top 15 \
  --outdir C7_FoldTree_download
```

The script downloads MGYP structures from ESM Atlas and UniProt/AFDB structures
through the AlphaFold DB API. It runs serially and sleeps between requests to
reduce ESM Atlas rate-limit failures.

Outputs:

```text
C7_FoldTree_download/
├── stage1_selection.tsv
├── stage1_structures/
├── stage1_structures_download_manifest.tsv
└── stage1_structures_failed.tsv
```

Re-running the same command resumes valid files.

## Stage 2: download the 35 edge-informed neighborhood structures

```bash
python c7_structure_downloader.py stage2 \
  --neighbor-ids Tree1A_edge_informed_35_ids.txt \
  --neighbor-manifest Tree1A_edge_informed_35_manifest.tsv \
  --outdir C7_FoldTree_download
```

A local structure directory can be preferred over public downloads:

```bash
python c7_structure_downloader.py stage2 \
  --neighbor-ids Tree1A_edge_informed_35_ids.txt \
  --neighbor-manifest Tree1A_edge_informed_35_manifest.tsv \
  --local-structure-dir /path/to/existing/pdbs \
  --outdir C7_FoldTree_download
```

## Merge for FoldMason/FoldTree

`Q5JBG6`, for example, is both a network anchor and an LPS/O-antigen hit. Merge
deduplicates it by canonical accession but retains both group labels.

```bash
python c7_structure_downloader.py merge \
  --manifest C7_FoldTree_download/stage1_structures_download_manifest.tsv \
  --manifest C7_FoldTree_download/stage2_neighborhood_structures_download_manifest.tsv \
  --outdir C7_FoldTree_download/foldtree_input
```

Outputs:

```text
foldtree_input/
├── structures/
├── foldtree_input_manifest.tsv
├── foldtree_input_paths.txt
├── foldtree_input_relative_paths.txt
└── FOLDTREE_NEXT_STEP.txt
```

## One-command alternative

```bash
python c7_structure_downloader.py all \
  --mgnify-hits C7_novel_priority_candidates.tsv \
  --lps-hits C7_LPS_Oantigen_Foldseek_hits.tsv \
  --neighbor-ids Tree1A_edge_informed_35_ids.txt \
  --neighbor-manifest Tree1A_edge_informed_35_manifest.tsv \
  --mgnify-top 15 \
  --outdir C7_FoldTree_download
```

## FoldTree order after download

Do not begin by interpreting a single full-length tree.

1. Run FoldMason on the merged directory.
2. Inspect core alignment, fragments, and long additions.
3. Trim LPS/O-antigen proteins to the shared GT-like domain where necessary.
4. Construct:
   - full-length diagnostic tree;
   - common-core FoldTree;
   - sensitivity tree excluding broad-fold functional anchors.
5. Map the categories from `foldtree_input_manifest.tsv`.

The primary test is:

> Do Cluster 7 and the strong MGnify proteins form a coherent structural
> lineage, with the C003 network intermediates connecting that lineage to the
> LPS/O-antigen GT anchors?
